﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CodingDojo6.MessageBarProperties
{
    public enum MessageState
    {
        Error,
        Ok,
        Delete
    }
}
