﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace CodingDojo6.Views
{
    /// <summary>
    /// Interaktionslogik für OverviewUserControl.xaml
    /// </summary>
    public partial class OverviewUserControl : UserControl
    {
        public OverviewUserControl()
        {
            InitializeComponent();
        }
    }
}
